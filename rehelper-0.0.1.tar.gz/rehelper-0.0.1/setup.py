from setuptools import  setup
setup(
    name="ReHelper",
    version='0.0.1',
    description='useful regular function method',
    license='MIT',
    packages=['ReHelper']





)